<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\StuffController;
use App\Http\Controllers\user\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::prefix('user')->name('user.')->group(function(){
    Route::middleware(['guest'])->group(function(){
        Route::view('/login', 'dashboard.user.login')->name('login');
        Route::view('/register', 'dashboard.user.register')->name('register');
        Route::post('/create', [UserController::class, 'create'])->name('create');
        Route::post('/check', [UserController::class, 'check'])->name('check');
    });

    Route::middleware(['auth'])->group(function () {
        Route::view('/home', 'dashboard.user.home')->name('home');
    });
});

Route::prefix('admin')->name('admin.')->group(function(){
    Route::middleware(['guest:admin'])->group(function(){
        Route::view('/login', 'dashboard.admin.login')->name('login');
        Route::post('/check', [AdminController::class, 'check'])->name('check');
    });

    Route::middleware(['auth:admin'])->group(function () {
        Route::view('/home', 'dashboard.admin.home')->name('home');
    });
});

Route::prefix('stuff')->name('stuff.')->group(function(){
    Route::middleware(['guest:stuff'])->group(function(){
        Route::view('/login', 'dashboard.stuff.login')->name('login');
        Route::view('/register', 'dashboard.stuff.register')->name('register');
        Route::post('/create', [StuffController::class, 'create'])->name('create');
        Route::post('/check', [StuffController::class, 'check'])->name('check');
    });

    Route::middleware(['auth:stuff'])->group(function () {
        Route::view('/home', 'dashboard.stuff.home')->name('home');
    });
});