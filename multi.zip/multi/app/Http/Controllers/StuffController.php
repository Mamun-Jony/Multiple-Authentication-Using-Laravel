<?php

namespace App\Http\Controllers;

use App\Models\Stuff;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StuffController extends Controller
{
    public function create(Request $request){
        $request->validate([
            'name' => 'required',
            'stuff' => 'required',
            'email' => 'required|email|unique:stuffs,email',
            'password' => 'required|min:5',
            'cpassword' => 'required|min:5|same:password',
        ]);

        $stuff = new Stuff();
        $stuff->name = $request->name;
        $stuff->stuff = $request->stuff;
        $stuff->email = $request->email;
        $stuff->password = \Hash::make($request->password);
        $save = $stuff->save();
        
        if($save){
            return redirect()->back()->with('success', 'You are register successfully!');
        }else{
            return redirect()->back()->with('fail', 'Something went wrong, register failed.');
        }
    }

    public function check(Request $request){
        $request->validate([
            'email' => 'required|email|exists:stuffs,email',
            'password' => 'required|min:5',
        ]); 

        $creds = $request->only('email', 'password');
        if(Auth::guard('stuff')->attempt($creds)){
            return redirect()->route('stuff.home');
        }else{
            return redirect()->route('stuff.login')->with('fail', 'Incorrect email or password');
        }   
    }
}
